import UIKit

let players = ["91":"Drake Caggiula", "22":"Ryan Carpenter", "77":"Kirby Dach", "12":"Alex DeBrincat", "36":"Matthew Highmore", "64":"David Kampf", "88":"Patric Kane", "8":"Dominik Kubalik", "92":"Alex Nylander", "20":"Brandon Saad", "65":"Andrew Shaw", "15":"Zack Smith", "17":"Dylan Strome", "19":"Jonathan Toews"]

let PlayerAge = ["Drake Caggiula":"26", "Ryan Carpenter":"29", "Kirby Dach":"19", "Alex DeBrincat":"22", "Matthew Highmore":"21", "David Kampf":"25", "Patric Kane":"32", "Dominik Kubalik":"25", "Alex Nylander":"22", "Brandon Saad":"28", "Andrew Shaw":"29", "Zack Smith":"32", "Dylan Strome":"22", "Jonathan Toews":"21", ]

let height = [70, 72, 76, 67, 71, 74, 70, 74, 73, 73, 71, 74, 75, 74]

let age = [26, 29, 19, 22, 21, 25, 32, 25, 22, 28, 29, 32, 22, 21]

let months = ["June", "January", "January", "December", "February", "January", "November", "August", "March", "October", "July", "April", "March", "April"]

let month_num = [6, 1, 1, 12, 2, 1, 11, 8, 3, 10, 7, 4, 3, 4]

var sum = 0
var counter = 0
var NewCounter = 0
var HeightSum = 0

for (PlayerName, PlayerAge) in PlayerAge {
    print("\(PlayerName) is \(PlayerAge) years old")
}

while counter < age.count {
    var value = age[counter]
     sum += value
    counter += 1
}
var average = sum / 14
print("The average age of the team is ",average)

while NewCounter < height.count {
    var NewVal = height[NewCounter]
    HeightSum += NewVal
    NewCounter += 1
}
var HeightAverage = HeightSum / 14
var feet = HeightAverage / 12
print("The average height is",feet,"feet")

var counting = [String:Int]()
months.forEach {counting[$0] = (counting[$0] ?? 0) + 1 }
if let (value, count) = counting.max(by: {$0.1 < $1.1}) {
    print("The most common birth month is", value)
}
